# Powershell 1

Claro! Aqui está um exemplo de uma rotina em PowerShell para baixar arquivos de uma URL:

## Define a URL de origem e o caminho de destino
$url = "http://exemplo.com/arquivo.zip"
$destino = "C:\caminho\para\destino\arquivo.zip"

## Baixa o arquivo usando Invoke-WebRequest
Invoke-WebRequest -Uri $url -OutFile $destino

## Exibe uma mensagem de confirmação
Write-Host "Download concluído: $destino"