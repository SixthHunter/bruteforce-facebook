/*
Client.c
Desenvolvido por Zeke.

Esse backdor trabalha no lado do cliente.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[BUFFER_SIZE] = {0};

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Falha ao criar socket");
        exit(EXIT_FAILURE);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        perror("Endereço inválido");
        close(sock);
        exit(EXIT_FAILURE);
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Falha ao conectar");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Exemplo de comando para copiar um arquivo
    char *comando = "copiar arquivo_origem.txt arquivo_destino.txt";
    send(sock, comando, strlen(comando), 0);
    printf("Comando enviado: %s\n", comando);

    close(sock);
    return 0;
}